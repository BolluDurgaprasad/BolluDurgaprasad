class allalpha 
{
  public static void main(String[] args) 
  {

    char c;

    for(c = 'a'; c <= 'z'; ++c)
      System.out.print(c + " ");
  }
}