import java.util.Scanner;
class divident5_1
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int numb;
        System.out.println("enter number=");
        numb=sc.nextInt();
        if(numb%5==0)
        {
            System.out.println("it is an multiplier of 5");
        }
        else
        {
            System.out.println("it is not an multiplier of 5");
        }
        
    }
}