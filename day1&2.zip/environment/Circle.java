//import statement for java program to read inputs using Scanner class 
import java.util.Scanner;
public class Circle
{ 
//Define main method
public static void main(String args[])
//Declare the variables
{
int radius;
float circum;
//Use the scanner class to provide radius at execution time
Scanner sc = new Scanner(System.in);
System.out.println("Enter radius as a positive integer");
radius = sc.nextInt();
circum = 2*(22/7)*radius;
System.out.println("the circumfurance of the circel is =" +circum);
//Caluculate the circumference of the circle
}
//Casting the floating-point value to int  
}
//Print the Result

